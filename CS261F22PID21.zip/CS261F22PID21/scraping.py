##-----------------------------(Libraries)-----------------------------------##
import time
from selenium import webdriver
from bs4 import BeautifulSoup
from selenium.webdriver.common.keys import Keys
from webdriver_manager.chrome import ChromeDriverManager
import pandas as pd
##------------------------------(Url)---------------------------------------##
urls = [
"https://www.youtube.com/results?search_query=start",
"https://www.youtube.com/results?search_query=ready",
"https://www.youtube.com/results?search_query=anybody",
"https://www.youtube.com/results?search_query=plastic",
"https://www.youtube.com/results?search_query=those",
"https://www.youtube.com/results?search_query=by",
"https://www.youtube.com/results?search_query=mixture",
"https://www.youtube.com/results?search_query=matter",
"https://www.youtube.com/results?search_query=dance",
       ]
##------------------------------(Scroll the page)-------------------------##
for url in urls:
    i=500
    #driver = webdriver.Chrome('chromedriver.exe')
    driver = webdriver.Chrome(ChromeDriverManager().install())
    driver.get(url)
    time.sleep(2)
    element=driver.find_element_by_tag_name('body')
    while(True):
        element.send_keys(Keys.PAGE_DOWN)
        time.sleep(2)
        i-=1
        if(i<=0):
            break
    
    ##------------------------------(Extract the required attributes)-----------------##
    content = driver.page_source.encode('utf-8').strip()
    soup = BeautifulSoup(content, 'html.parser')
    titles = soup.findAll('a',id='video-title')
    views = soup.findAll('span',class_='inline-metadata-item style-scope ytd-video-meta-block')
    channalName = soup.findAll('a',class_='yt-simple-endpoint style-scope yt-formatted-string')
    description = soup.findAll('span',class_='style-scope yt-formatted-string')
    video_urls = soup.findAll('a',id='video-title')
    ##------------------------------(Store the data into list)-----------------##
    videoTitle_=[]
    list1=[]
    list2=[]
    channelName_=[]
    description_=[]
    videoURL_=[]
    length_=[]
    channelURL_=[]
    print(len(titles))
    i = 0 # views and postedDate
    for j in range(len(titles)):
        videoTitle_.append(titles[j].text)
        list1.append(views[i].text)
        list2.append(views[i+1].text)
        channelName_.append(channalName[j].text)
        description_.append(description[j].text)
        videoURL_.append("https://www.youtube.com{}".format(video_urls[j].get('href')))
        channelURL_.append("https://www.youtube.com{}".format(channalName[j].get('href')))
        i+=2
    ##------------------------------(Store the data into CSV Files)-----------------##
    df = pd.DataFrame({'Name':videoTitle_  ,'Views':list1 ,'PostedTime':list2,'Description':description_ ,'URL':videoURL_ ,'Channel Name':channelName_ ,'Channel URL':channelURL_})
    df.to_csv('Data.csv', index=False,  mode='a', header=False)
