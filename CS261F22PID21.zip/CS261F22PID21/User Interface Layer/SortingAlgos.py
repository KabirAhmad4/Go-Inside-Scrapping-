# -*- coding: utf-8 -*-
"""
Created on Wed Oct 12 07:03:07 2022

@author: HS
"""

import math
def BubbleSort2(array,start,end):
    i=0
    swapped = True
    while i<end and swapped == True:
        swapped = False
        for j in range(start,end-i):
            if(array[j] > array[j+1]):
                temp = array[j]
                array[j] = array[j+1]
                array[j+1] = temp
                swapped = True
        i+=1
def BubbleSortDescending2(array,start,end):
    i=0
    swapped = True
    while i<end and swapped == True:
        swapped = False
        for j in range(start,end-i):
            if(array[j] < array[j+1]):
                temp = array[j]
                array[j] = array[j+1]
                array[j+1] = temp
                swapped = True
        i+=1
def BubbleSortString2(array,start,end):
    i=0
    swapped = True
    while i<end and swapped == True:
        swapped = False
        for j in range(start,end-i):
            if(str(array[j]) > str(array[j+1])):
                temp = array[j]
                array[j] = array[j+1]
                array[j+1] = temp
                swapped = True
        i+=1
def BubbleSortStringDescending2(array,start,end):
    i=0
    swapped = True
    while i<end and swapped == True:
        swapped = False
        for j in range(start,end-i):
            if(str(array[j]) <str( array[j+1])):
                temp = array[j]
                array[j] = array[j+1]
                array[j+1] = temp
                swapped = True
        i+=1




def SelectionSort2(array,start,end):
    for i in range(start,end+1):
        min = i
        for j in range(i+1,end+1):
            if(array[min] > array[j]):
                temp = array[min]
                array[min] = array[j]
                array[j] = temp
                
def SelectionSortString2(array,start,end):
    for i in range(start,end+1):
        min = i
        for j in range(i+1,end+1):
            if(str(array[min]) > str(array[j])):
                temp = array[min]
                array[min] = array[j]
                array[j] = temp                
                
def SelectionSortStringDescending2(array,start,end):
    for i in range(start,end+1):
        maximum = i
        for j in range(i+1,end+1):
            if(array[maximum] < array[j]):
                temp = array[maximum]
                array[maximum] = array[j]
                array[j] = temp
                                
def SelectionSortDescending2(array,start,end):
    for i in range(start,end+1):
        maximum = i
        for j in range(i+1,end+1):
            if(array[maximum] < array[j]):
                temp = array[maximum]
                array[maximum] = array[j]
                array[j] = temp                
                

def HybridMergeSort(A,p,r):
    if r-p>23:
        q = math.floor((p+r)/2)
        HybridMergeSort(A,p,q)
        HybridMergeSort(A,q+1,r)

        Merge2(A,p,q,r)

    else:
        SelectionSort2(A, p, r)
        
def Merge2(A,p,q,r):
    L = []
    R = []
    for i in range(0,q-p+1):
        L.append(A[p+i])
    for j in range(0,r-q):
        R.append(A[q+j+1])
    #L = A[p:q+1]
    #R = A[q+1:r+1]
    L.append(100000000000)
    R.append(100000000000)
    i,j = 0,0
    for k in range(p,r+1):
        if(L[i] < R[j]):
            A[k] = L[i]
            i=i+1
        else:
            A[k] = R[j]
            j = j+1

def InsertionSort2(array,start,end):
    for i in range(start, end):
        key=array[i]
        j=i-1
        while key< array[j] and j>=0:
            array[j+1]=array[j]
            j=j-1
        array[j+1]=key
def InsertionSort2return(array,start,end):
    for i in range(start, end):
        key=array[i]
        j=i-1
        while key< array[j] and j>=0:
            array[j+1]=array[j]
            j=j-1
        array[j+1]=key
    return array     

def InsertionSortString2(array,start,end):
    for i in range(start, end):
        key=array[i]
        j=i-1
        while str(key)< str(array[j]) and j>=0:
            array[j+1]=array[j]
            j=j-1
        array[j+1]=key
    

def InsertionSortDecending2(array,start,end):
    for i in range(start, end):
        key=array[i]
        j=i-1
        while key> array[j] and j>=0:
            array[j+1]=array[j]
            j=j-1
        array[j+1]=key


def InsertionSortStringDecending2(array,start,end):
    for i in range(start, end):
        key=array[i]
        j=i-1
        while str(key)> str(array[j]) and j>=0:
            array[j+1]=array[j]
            j=j-1
        array[j+1]=key
    




def MergeSort2(array,start,end):
    if start!=end:
        mid=((start+end)/2)
        mid=math.floor(mid)
        MergeSort2(array,start,mid)
        MergeSort2(array,mid+1,end)
        Merge2(array,start,mid,end)
    
            
            
import math
def countingSort(array, place):
    size = len(array)
    output = [0] * size
    count = [0] * 10
    # Calculate count of elements
    for i in range(0, size):
        index = array[i] // place
        count[index % 10] += 1

    # Calculate cumulative count
    for i in range(1, 10):
        count[i] += count[i - 1]

    # Place the elements in sorted order
    i = size - 1
    while i >= 0:
        index = array[i] // place
        output[count[index % 10] - 1] = array[i]
        count[index % 10] -= 1
        i -= 1

    for i in range(0, size):
        array[i] = output[i]
        


# Main function to implement radix sort
def radixSort(array):
    max_element = max(array)
    check=False
    for i in range (0,len(array)):
        if type(array[i])==float:
            check==True
    if check ==True:convertINT(array)          
    
    place = 1
    while math.floor(max_element / place) > 0:
        #print("before",array,place)
        
        countingSort(array, place)
        place *= 10
    if check ==True:convertFloat(array)    

def bucketSort(x):
	arr = []
	slot_num = 10 
	for i in range(slot_num):
		arr.append([])
	x,power=convertInFloat(x)	
    
	for j in x:
		index_b = int(slot_num * j)
		arr[index_b].append(j)

	for i in range(slot_num):
		arr[i] = InsertionSort2return(arr[i],0,len(arr[i]))

	k = 0
	for i in range(slot_num):
		for j in range(len(arr[i])):
			x[k] = convert_Into_int(arr[i][j],power)
			k += 1
     
def convertInFloat(array):
    number=max(array)
    count=0
    while number!=0:
        number=number//10
        count+=1    
    for i in range(0,len(array)):
        array[i]=array[i]/math.pow(10,count)
    return array,count


def convert_Into_int(number,count):

        number=number*math.pow(10,count)
        return int(number)

def convertINT(array):
    for i in range(0,len(array)):
            array[i]= int(array[i])
def convertFloat(array):
    for i in range(0,len(array)):
            array[i]= float(array[i])            


def QuickSortDescending2(A,p,r):
    if p<r:
        q=partitonDescending2(A,p,r)
        QuickSortDescending2(A,p,q-1)
        QuickSortDescending2(A,q+1,r)

def partitonDescending2(A,p,r):
    key = A[r]
    i=p-1
    for j in range(p,r):
        if A[j]>=key:
            i=i+1
            temp=A[i]
            A[i]=A[j]
            A[j]=temp
    change=A[i+1]
    A[i+1]=A[r]
    A[r]=change
    return i+1     

def InsertionSortDescending2(array,start,end):
    for i in range(start, end):
        key=array[i]
        j=i-1
        while key> array[j] and j>=0:
            array[j+1]=array[j]
            j=j-1
        array[j+1]=key



                
    
def HybridMergeInsertionSort2(A,p,r):
    if r-p>43:
        q = math.floor((p+r)/2)
        HybridMergeInsertionSort2(A, p, q)
        HybridMergeInsertionSort2(A,q+1,r)

        Merge2(A,p,q,r)

    else:
        InsertionSort2(A, p,r)
def MergeString2(A,p,q,r):
    L = []
    R = []
    for i in range(0,q-p+1):
        L.append(A[p+i])
    for j in range(0,r-q):
        R.append(A[q+j+1])
    #L = A[p:q+1]
    #R = A[q+1:r+1]
    L.append("zzzzzzzzzzzzzzzzzzzzz")
    R.append("zzzzzzzzzzzzzzzzzzzzz")
    
    
    i,j = 0,0
    for k in range(p,r+1):
        LA = makeAscii(L[i])
        RA = makeAscii(R[j])
        if(''.join(map(chr,compareAscii(LA, RA, 0))) == L[i]):
            A[k] = L[i]
            i=i+1
        else:
            A[k] = R[j]
            j = j+1
def makeAscii(A):
    arr = []
    for character in A:
        arr.append(ord(character))
    return arr

def compareAscii(A,B,n):
    if(n==0):
        A.append(-1000)
        B.append(-1000)
    if(A[n] < B[n]):
        A.pop()
        return A
    elif(A[n] > B[n]):
        B.pop()
        return B
    else:
        return compareAscii(A, B, n+1)

def QuickSort2(A,p,r):
    if p<r:
        q=partiton2(A,p,r)
        QuickSort2(A,p,q-1)
        QuickSort2(A,q+1,r)

def partiton2(A,p,r):
    key = A[r]
    i=p-1
    for j in range(p,r):
        if A[j]<=key:
            i=i+1
            temp=A[i]
            A[i]=A[j]
            A[j]=temp
    change=A[i+1]
    A[i+1]=A[r]
    A[r]=change
    return i+1  
         
def QuickSortString2(A,p,r):
    if p<r:
        q=partitonString2(A,p,r)
        QuickSortString2(A,p,q-1)
        QuickSortString2(A,q+1,r)

def partitonString2(A,p,r):
    key = A[r]
    i=p-1
    for j in range(p,r):
        if str(A[j])<=str(key):
            i=i+1
            temp=A[i]
            A[i]=A[j]
            A[j]=temp
    change=A[i+1]
    A[i+1]=A[r]
    A[r]=change
    return i+1  
    
def QuickSortStringDecending2(A,p,r):
    if p<r:
        q=partitonString2(A,p,r)
        QuickSortString2(A,p,q-1)
        QuickSortString2(A,q+1,r)

def partitonStringDecending2(A,p,r):
    key = A[r]
    i=p-1
    for j in range(p,r):
        if str(A[j])<=str(key):
            i=i+1
            temp=A[i]
            A[i]=A[j]
            A[j]=temp
    change=A[i+1]
    A[i+1]=A[r]
    A[r]=change
    return i+1 



#Insertion SORT for int Coulumns in UI tables according to column1 Titles

def InsertionSortValues(array,start,end,array2,array3,array4,array5,array6,array7):
    for i in range(start, end):
        key=array[i]
        key2=array2[i]
        key3=array3[i]
        key4=array4[i]
        key5=array5[i]        
        key6=array6[i]        
        key7=array7[i]        
        j=i-1
        while key< array[j] and j>=0:
            array[j+1]=array[j]
            array2[j+1]=array2[j]
            array3[j+1]=array3[j]
            array4[j+1]=array4[j]
            array5[j+1]=array5[j]
            array6[j+1]=array6[j]
            array7[j+1]=array7[j]   
            j=j-1
        array[j+1]=key
        array2[j+1]=key2
        array3[j+1]=key3
        array4[j+1]=key4
        array5[j+1]=key5
        array6[j+1]=key6
        array7[j+1]=key7

#Insertion SORT for int value  Coulumns in UI tables according to column2 for decreasing 

def InsertionSortValuesDecreasing(array,start,end,array2,array3,array4,array5,array6,array7):
    for i in range(start, end):
        key=array[i]
        key2=array2[i]
        key3=array3[i]
        key4=array4[i]
        key5=array5[i]        
        key6=array6[i]        
        key7=array7[i]        
        j=i-1
        while key> array[j] and j>=0:
            array[j+1]=array[j]
            array2[j+1]=array2[j]
            array3[j+1]=array3[j]
            array4[j+1]=array4[j]
            array5[j+1]=array5[j]
            array6[j+1]=array6[j]
            array7[j+1]=array7[j]   
            j=j-1
        array[j+1]=key
        array2[j+1]=key2
        array3[j+1]=key3
        array4[j+1]=key4
        array5[j+1]=key5
        array6[j+1]=key6
        array7[j+1]=key7
        

#Insertion SORT for String Coulumns in UI tables according to column1 Titles

def InsertionSortStringTitles(array,start,end,array2,array3,array4,array5,array6,array7):
    for i in range(start, end):
        key=array[i]
        key2=array2[i]
        key3=array3[i]
        key4=array4[i]
        key5=array5[i]        
        key6=array6[i]        
        key7=array7[i]        
        j=i-1
        while str(key)< str(array[j]) and j>=0:
            array[j+1]=array[j]
            array2[j+1]=array2[j]
            array3[j+1]=array3[j]
            array4[j+1]=array4[j]
            array5[j+1]=array5[j]
            array6[j+1]=array6[j]
            array7[j+1]=array7[j]   
            j=j-1
        array[j+1]=key
        array2[j+1]=key2
        array3[j+1]=key3
        array4[j+1]=key4
        array5[j+1]=key5
        array6[j+1]=key6
        array7[j+1]=key7

#Insertion SORT for String Coulumns in UI tables according to column1 Titles for decreasing 

def InsertionSortStringDecreasingTitles(array,start,end,array2,array3,array4,array5,array6,array7):
    for i in range(start, end):
        key=array[i]
        key2=array2[i]
        key3=array3[i]
        key4=array4[i]
        key5=array5[i]        
        key6=array6[i]        
        key7=array7[i]        
        j=i-1
        while str(key)> str(array[j]) and j>=0:
            array[j+1]=array[j]
            array2[j+1]=array2[j]
            array3[j+1]=array3[j]
            array4[j+1]=array4[j]
            array5[j+1]=array5[j]
            array6[j+1]=array6[j]
            array7[j+1]=array7[j]   
            j=j-1
        array[j+1]=key
        array2[j+1]=key2
        array3[j+1]=key3
        array4[j+1]=key4
        array5[j+1]=key5
        array6[j+1]=key6
        array7[j+1]=key7

# for ui for = column 2,3 Bubble Sort
def BubbleSortValues(array,start,end,array2,array3,array4,array5,array6,array7):
    i=0
    swapped = True
    while i<end and swapped == True:
        swapped = False
        for j in range(start,end-i):
            if(array[j]> array[j+1]):
                
                temp = array[j]
                temp2 = array2[j]
                temp3 = array3[j]
                temp4 = array4[j]
                temp5 = array5[j]
                temp6 = array6[j]
                temp7 = array7[j]
            
                array[j] = array[j+1]
                array2[j] = array2[j+1]
                array3[j] = array3[j+1]
                array4[j] = array4[j+1]
                array5[j] = array5[j+1]
                array6[j] = array6[j+1]
                array7[j] = array7[j+1]
                
                array[j+1] = temp
                array2[j+1] = temp2
                array3[j+1] = temp3
                array4[j+1] = temp4
                array5[j+1] = temp5
                array6[j+1] = temp6
                array7[j+1] = temp7
                
                swapped = True
        i+=1
     

## for ui for titles column 1 Bubble Sort Decending
def BubbleSortValuesDecending(array,start,end,array2,array3,array4,array5,array6,array7):
    i=0
    swapped = True
    while i<end and swapped == True:
        swapped = False
        for j in range(start,end-i):
            if(array[j] < array[j+1]):
                
                temp = array[j]
                temp2 = array2[j]
                temp3 = array3[j]
                temp4 = array4[j]
                temp5 = array5[j]
                temp6 = array6[j]
                temp7 = array7[j]
            
                array[j] = array[j+1]
                array2[j] = array2[j+1]
                array3[j] = array3[j+1]
                array4[j] = array4[j+1]
                array5[j] = array5[j+1]
                array6[j] = array6[j+1]
                array7[j] = array7[j+1]
                
                array[j+1] = temp
                array2[j+1] = temp2
                array3[j+1] = temp3
                array4[j+1] = temp4
                array5[j+1] = temp5
                array6[j+1] = temp6
                array7[j+1] = temp7
                
                swapped = True
        i+=1



# for ui for titles column 1 Bubble Sort
def BubbleSortString(array,start,end,array2,array3,array4,array5,array6,array7):
    i=0
    swapped = True
    while i<end and swapped == True:
        swapped = False
        for j in range(start,end-i):
            if(str(array[j]) > str(array[j+1])):
                
                temp = array[j]
                temp2 = array2[j]
                temp3 = array3[j]
                temp4 = array4[j]
                temp5 = array5[j]
                temp6 = array6[j]
                temp7 = array7[j]
            
                array[j] = array[j+1]
                array2[j] = array2[j+1]
                array3[j] = array3[j+1]
                array4[j] = array4[j+1]
                array5[j] = array5[j+1]
                array6[j] = array6[j+1]
                array7[j] = array7[j+1]
                
                array[j+1] = temp
                array2[j+1] = temp2
                array3[j+1] = temp3
                array4[j+1] = temp4
                array5[j+1] = temp5
                array6[j+1] = temp6
                array7[j+1] = temp7
                
                swapped = True
        i+=1
     

## for ui for titles column 1 Bubble Sort Decending
def BubbleSortStringDecending(array,start,end,array2,array3,array4,array5,array6,array7):
    i=0
    swapped = True
    while i<end and swapped == True:
        swapped = False
        for j in range(start,end-i):
            if(str(array[j]) < str(array[j+1])):
                
                temp = array[j]
                temp2 = array2[j]
                temp3 = array3[j]
                temp4 = array4[j]
                temp5 = array5[j]
                temp6 = array6[j]
                temp7 = array7[j]
            
                array[j] = array[j+1]
                array2[j] = array2[j+1]
                array3[j] = array3[j+1]
                array4[j] = array4[j+1]
                array5[j] = array5[j+1]
                array6[j] = array6[j+1]
                array7[j] = array7[j+1]
                
                array[j+1] = temp
                array2[j+1] = temp2
                array3[j+1] = temp3
                array4[j+1] = temp4
                array5[j+1] = temp5
                array6[j+1] = temp6
                array7[j+1] = temp7
                
                swapped = True
        i+=1


# Selection Sort on Tilea UI
def SelectionSortString(array,start,end,array2,array3,array4,array5,array6,array7):
    for i in range(start,end+1):
        min = i
        for j in range(i+1,end+1):
            if(str(array[min]) > str(array[j])):
                temp = array[min]
                temp2 = array2[min]               
                temp3 = array3[min]
                temp4 = array4[min]
                temp5 = array5[min]
                temp6 = array6[min]
                temp7 = array7[min]
                
                array[min] = array[j]
                array2[min] = array2[j]
                array3[min] = array3[j]
                array4[min] = array4[j]
                array5[min] = array5[j]
                array6[min] = array6[j]
                array7[min] = array7[j]
                
                array[j] = temp
                array2[j] = temp2
                array3[j] = temp3
                array4[j] = temp4
                array5[j] = temp5
                array6[j] = temp6
                array7[j] = temp7
                
    #return array,array2,array3,array4,array5,array6,array7 

# Selection Sort on Tilea UI
def SelectionSortStringDecending(array,start,end,array2,array3,array4,array5,array6,array7):
    for i in range(start,end+1):
        min = i
        for j in range(i+1,end+1):
            if(str(array[min]) < str(array[j])):
                temp = array[min]
                temp2 = array2[min]               
                temp3 = array3[min]
                temp4 = array4[min]
                temp5 = array5[min]
                temp6 = array6[min]
                temp7 = array7[min]
                
                array[min] = array[j]
                array2[min] = array2[j]
                array3[min] = array3[j]
                array4[min] = array4[j]
                array5[min] = array5[j]
                array6[min] = array6[j]
                array7[min] = array7[j]
                
                array[j] = temp
                array2[j] = temp2
                array3[j] = temp3
                array4[j] = temp4
                array5[j] = temp5
                array6[j] = temp6
                array7[j] = temp7
                
    #return array,array2,array3,array4,array5,array6,array7     

def SelectionSortValues(array,start,end,array2,array3,array4,array5,array6,array7):
    for i in range(start,end+1):
        min = i
        for j in range(i+1,end+1):
            if(array[min] > array[j]):
                temp = array[min]
                temp2 = array2[min]               
                temp3 = array3[min]
                temp4 = array4[min]
                temp5 = array5[min]
                temp6 = array6[min]
                temp7 = array7[min]
                
                array[min] = array[j]
                array2[min] = array2[j]
                array3[min] = array3[j]
                array4[min] = array4[j]
                array5[min] = array5[j]
                array6[min] = array6[j]
                array7[min] = array7[j]
                
                array[j] = temp
                array2[j] = temp2
                array3[j] = temp3
                array4[j] = temp4
                array5[j] = temp5
                array6[j] = temp6
                array7[j] = temp7
                
# Selection Sort on Tilea UI
def SelectionSortValuesDecending(array,start,end,array2,array3,array4,array5,array6,array7):
    for i in range(start,end+1):
        min = i
        for j in range(i+1,end+1):
            if(array[min] < array[j]):
                temp = array[min]
                temp2 = array2[min]               
                temp3 = array3[min]
                temp4 = array4[min]
                temp5 = array5[min]
                temp6 = array6[min]
                temp7 = array7[min]
                
                array[min] = array[j]
                array2[min] = array2[j]
                array3[min] = array3[j]
                array4[min] = array4[j]
                array5[min] = array5[j]
                array6[min] = array6[j]
                array7[min] = array7[j]
                
                array[j] = temp
                array2[j] = temp2
                array3[j] = temp3
                array4[j] = temp4
                array5[j] = temp5
                array6[j] = temp6
                array7[j] = temp7
                
     


def QuickSort(array,p,r,array2,array3,array4,array5,array6,array7):
    if p<r:
        q=partiton(array,p,r,array2,array3,array4,array5,array6,array7)
        QuickSort(array,p,q-1,array2,array3,array4,array5,array6,array7)
        QuickSort(array,q+1,r,array2,array3,array4,array5,array6,array7)

def partiton(A,p,r,array2,array3,array4,array5,array6,array7):
    key = A[r]
    key2 = array2[r]
    key3 = array3[r]
    key4 = array4[r]
    key5 = array5[r]
    key6 = array6[r]
    key7 = array7[r]
    
    i=p-1
    for j in range(p,r):
        if float(A[j])<=float(key):
            
            i=i+1
            
            temp=A[i]
            temp2=array2[i]
            temp3=array3[i]
            temp4=array4[i]
            temp5=array5[i]
            temp6=array6[i]
            temp7=array7[i]
            
            A[i]=A[j]
            array2[i]=array2[j]
            array3[i]=array3[j]
            array4[i]=array4[j]
            array5[i]=array5[j]
            array6[i]=array6[j]
            array7[i]=array7[j]

            A[j]=temp
            array2[j]=temp2
            array3[j]=temp3
            array4[j]=temp4
            array5[j]=temp5
            array6[j]=temp6
            array7[j]=temp7
                
    change=A[i+1]
    change2=array2[i+1]
    change3=array3[i+1]
    change4=array4[i+1]
    change5=array5[i+1]
    change6=array6[i+1]
    change7=array7[i+1]
    
    A[i+1]=A[r]
    array2[i+1]=array2[r]
    array3[i+1]=array2[r]
    array4[i+1]=array3[r]
    array5[i+1]=array4[r]
    array6[i+1]=array5[r]
    array7[i+1]=array6[r]
    
    A[r]=change
    array2[r]=change2
    array3[r]=change3
    array4[r]=change4
    array5[r]=change5
    array6[r]=change6
    array7[r]=change7    
    
    return i+1 


def QuickSortTitlesString(array,p,r,array2,array3,array4,array5,array6,array7):
    if p<r:
        q=partitonTitlesString(array,p,r,array2,array3,array4,array5,array6,array7)
        QuickSortTitlesString(array,p,q-1,array2,array3,array4,array5,array6,array7)
        QuickSortTitlesString(array,q+1,r,array2,array3,array4,array5,array6,array7)

def partitonTitlesString(A,p,r,array2,array3,array4,array5,array6,array7):
    key = A[r]
    key2 = array2[r]
    key3 = array3[r]
    key4 = array4[r]
    key5 = array5[r]
    key6 = array6[r]
    key7 = array7[r]
    
    i=p-1
    for j in range(p,r):
        if str(A[j])<=str(key):
            i=i+1
            
            temp=A[i]
            temp2=array2[i]
            temp3=array3[i]
            temp4=array4[i]
            temp5=array5[i]
            temp6=array6[i]
            temp7=array7[i]
            
            A[i]=A[j]
            array2[i]=array2[j]
            array3[i]=array3[j]
            array4[i]=array4[j]
            array5[i]=array5[j]
            array6[i]=array6[j]
            array7[i]=array7[j]

            A[j]=temp
            array2[j]=temp2
            array3[j]=temp3
            array4[j]=temp4
            array5[j]=temp5
            array6[j]=temp6
            array7[j]=temp7
                
    change=A[i+1]
    change2=array2[i+1]
    change3=array3[i+1]
    change4=array4[i+1]
    change5=array5[i+1]
    change6=array6[i+1]
    change7=array7[i+1]
    
    A[i+1]=A[r]
    array2[i+1]=array2[r]
    array3[i+1]=array2[r]
    array4[i+1]=array3[r]
    array5[i+1]=array4[r]
    array6[i+1]=array5[r]
    array7[i+1]=array6[r]
    
    A[r]=change
    array2[r]=change2
    array3[r]=change3
    array4[r]=change4
    array5[r]=change5
    array6[r]=change6
    array7[r]=change7    
    
    return i+1 

def QuickSortTitlesStringDecending(array,p,r,array2,array3,array4,array5,array6,array7):
    if p<r:
        q=partitonTitlesStringDecending(array,p,r,array2,array3,array4,array5,array6,array7)
        QuickSortTitlesStringDecending(array,p,q-1,array2,array3,array4,array5,array6,array7)
        QuickSortTitlesStringDecending(array,q+1,r,array2,array3,array4,array5,array6,array7)

def partitonTitlesStringDecending(A,p,r,array2,array3,array4,array5,array6,array7):
    key = A[r]
    key2 = array2[r]
    key3 = array3[r]
    key4 = array4[r]
    key5 = array5[r]
    key6 = array6[r]
    key7 = array7[r]
    
    i=p-1
    for j in range(p,r):
        if str(A[j])>=str(key):
            i=i+1
            
            temp=A[i]
            temp2=array2[i]
            temp3=array3[i]
            temp4=array4[i]
            temp5=array5[i]
            temp6=array6[i]
            temp7=array7[i]
            
            A[i]=A[j]
            array2[i]=array2[j]
            array3[i]=array3[j]
            array4[i]=array4[j]
            array5[i]=array5[j]
            array6[i]=array6[j]
            array7[i]=array7[j]

            A[j]=temp
            array2[j]=temp2
            array3[j]=temp3
            array4[j]=temp4
            array5[j]=temp5
            array6[j]=temp6
            array7[j]=temp7
                
    change=A[i+1]
    change2=array2[i+1]
    change3=array3[i+1]
    change4=array4[i+1]
    change5=array5[i+1]
    change6=array6[i+1]
    change7=array7[i+1]
    
    A[i+1]=A[r]
    array2[i+1]=array2[r]
    array3[i+1]=array2[r]
    array4[i+1]=array3[r]
    array5[i+1]=array4[r]
    array6[i+1]=array5[r]
    array7[i+1]=array6[r]
    
    A[r]=change
    array2[r]=change2
    array3[r]=change3
    array4[r]=change4
    array5[r]=change5
    array6[r]=change6
    array7[r]=change7    
    
    return i+1




def QuickSortDecending(array,p,r,array2,array3,array4,array5,array6,array7):
    if p<r:
        q=partitonDecending(array,p,r,array2,array3,array4,array5,array6,array7)
        QuickSortDecending(array,p,q-1,array2,array3,array4,array5,array6,array7)
        QuickSortDecending(array,q+1,r,array2,array3,array4,array5,array6,array7)

def partitonDecending(A,p,r,array2,array3,array4,array5,array6,array7):
    key = A[r]
    key2 = array2[r]
    key3 = array3[r]
    key4 = array4[r]
    key5 = array5[r]
    key6 = array6[r]
    key7 = array7[r]
    
    i=p-1
    for j in range(p,r):
        if A[j]>=key:
            i=i+1
            
            temp=A[i]
            temp2=array2[i]
            temp3=array3[i]
            temp4=array4[i]
            temp5=array5[i]
            temp6=array6[i]
            temp7=array7[i]
            
            A[i]=A[j]
            array2[i]=array2[j]
            array3[i]=array3[j]
            array4[i]=array4[j]
            array5[i]=array5[j]
            array6[i]=array6[j]
            array7[i]=array7[j]

            A[j]=temp
            array2[j]=temp2
            array3[j]=temp3
            array4[j]=temp4
            array5[j]=temp5
            array6[j]=temp6
            array7[j]=temp7
                
    change=A[i+1]
    change2=array2[i+1]
    change3=array3[i+1]
    change4=array4[i+1]
    change5=array5[i+1]
    change6=array6[i+1]
    change7=array7[i+1]
    
    A[i+1]=A[r]
    array2[i+1]=array2[r]
    array3[i+1]=array2[r]
    array4[i+1]=array3[r]
    array5[i+1]=array4[r]
    array6[i+1]=array5[r]
    array7[i+1]=array6[r]
    
    A[r]=change
    array2[r]=change2
    array3[r]=change3
    array4[r]=change4
    array5[r]=change5
    array6[r]=change6
    array7[r]=change7    
    
    return i+1 


def MergeSort(array,array2,array3,array4,array5,array6,array7,start,end):
    if start!=end:
        mid=math.floor((start+end)/2)
        MergeSort(array,array2,array3,array4,array5,array6,array7,start,mid)
        MergeSort(array,array2,array3,array4,array5,array6,array7,mid+1,end)
        MergeA(array,array2,array3,array4,array5,array6,array7,start,mid,end)
                              
def MergeA(A,array2,array3,array4,array5,array6,array7,p,q,r):
    L = []
    L2= []
    L3= []
    L4= []
    L5= []
    L6= []
    L7= []
    
    R = []
    R2 = []
    R3 = []
    R4 = []    
    R5 = []
    R6 = []
    R7 = []
    
    for i in range(0,q-p+1):
        L.append(A[p+i])
        L2.append(array2[p+i])
        L3.append(array3[p+i])
        L4.append(array4[p+i])
        L5.append(array5[p+i])
        L6.append(array6[p+i])
        L7.append(array7[p+i])
        
    for j in range(0,r-q):
        R.append(A[q+j+1])
        R2.append(array2[q+j+1])
        R3.append(array3[q+j+1])
        R4.append(array4[q+j+1])
        R5.append(array5[q+j+1])
        R6.append(array6[q+j+1])
        R7.append(array7[q+j+1])
        
        
    #L = A[p:q+1]
    #R = A[q+1:r+1]
    L.append(100000000000)
    R.append(100000000000)
    L2.append(100000000000)
    R2.append(100000000000)
    L3.append(100000000000)
    R3.append(100000000000)
    L4.append(100000000000)
    R4.append(100000000000)
    L5.append(100000000000)
    R5.append(100000000000)
    L6.append(100000000000)
    R6.append(100000000000)
    L7.append(100000000000)
    R7.append(100000000000)
    
    
    
    i,j = 0,0
    for k in range(p,r+1):
        if(int(L[i]) < int(R[j])):
            A[k] = L[i]
            array2[k] = L2[i]
            array3[k] = L3[i] 
            array4[k] = L4[i]
            array5[k] = L5[i]
            array6[k] = L6[i]
            array7[k] = L7[i]
            
            i=i+1
        else:
            A[k] = R[j]
            array2[k] = R2[j]
            array3[k] = R3[j]
            array4[k] = R4[j]
            array5[k] = R5[j]
            array6[k] = R6[j]
            array7[k] = R7[j]
            
            j = j+1


def MergeSortDecending(array,array2,array3,array4,array5,array6,array7,start,end):
    if start!=end:
        mid=math.floor((start+end)/2)
        MergeSortDecending(array,array2,array3,array4,array5,array6,array7,start,mid)
        MergeSortDecending(array,array2,array3,array4,array5,array6,array7,mid+1,end)
        MergeDecending(array,array2,array3,array4,array5,array6,array7,start,mid,end)
                              
def MergeDecending(A,array2,array3,array4,array5,array6,array7,p,q,r):
    L = []
    L2= []
    L3= []
    L4= []
    L5= []
    L6= []
    L7= []
    
    R = []
    R2 = []
    R3 = []
    R4 = []    
    R5 = []
    R6 = []
    R7 = []
    
    for i in range(0,q-p+1):
        L.append(A[p+i])
        L2.append(array2[p+i])
        L3.append(array3[p+i])
        L4.append(array4[p+i])
        L5.append(array5[p+i])
        L6.append(array6[p+i])
        L7.append(array7[p+i])
        
    for j in range(0,r-q):
        R.append(A[q+j+1])
        R2.append(array2[q+j+1])
        R3.append(array3[q+j+1])
        R4.append(array4[q+j+1])
        R5.append(array5[q+j+1])
        R6.append(array6[q+j+1])
        R7.append(array7[q+j+1])
        
        
    #L = A[p:q+1]
    #R = A[q+1:r+1]
    L.append(-100000000000000000000)
    R.append(-1000000000000000000000)
    L2.append(-100000000000000000000)
    R2.append(-100000000000000000000)
    L3.append(-100000000000000000000)
    R3.append(-100000000000000000000)
    L4.append(-100000000000000000000)
    R4.append(-100000000000000000000)
    L5.append(-100000000000000000000)
    R5.append(-100000000000000000000)
    L6.append(-100000000000000000000)
    R6.append(-100000000000000000000)
    L7.append(-100000000000000000000)
    R7.append(-100000000000000000000)
    
    
    
    i,j = 0,0
    for k in range(p,r+1):
        if(L[i]> R[j]):
            A[k] = L[i]
            array2[k] = L2[i]
            array3[k] = L3[i] 
            array4[k] = L4[i]
            array5[k] = L5[i]
            array6[k] = L6[i]
            array7[k] = L7[i]
            
            i=i+1
        else:
            A[k] = R[j]
            array2[k] = R2[j]
            array3[k] = R3[j]
            array4[k] = R4[j]
            array5[k] = R5[j]
            array6[k] = R6[j]
            array7[k] = R7[j]
            
            j = j+1
