# -*- coding: utf-8 -*-
"""
Created on Sun Oct 30 09:07:01 2022

@author: Hammad Hassan
"""
import time
from selenium import webdriver
from bs4 import BeautifulSoup
from selenium.webdriver.common.keys import Keys
from webdriver_manager.chrome import ChromeDriverManager
import pandas as pd




##------------------------------(Scroll the page)-------------------------##
def Scraping(fileName,weblink,tag1,tag2,tag3,tag4,tag5,tag6,tag7,att1,att2,att3,att4,att5,att6,att7):
    i=10
    #driver = webdriver.Chrome('chromedriver.exe')
    driver = webdriver.Chrome(ChromeDriverManager().install())
    driver.get(weblink)
    time.sleep(2)
    element=driver.find_element_by_tag_name('body')
    while(True):
        element.send_keys(Keys.PAGE_DOWN)
        time.sleep(2)
        i-=1
        if(i<=0):
            break
    
    ##------------------------------(Extract the required attributes)-----------------##
    content = driver.page_source.encode('utf-8').strip()
    soup = BeautifulSoup(content, 'html.parser')
    titles = soup.findAll(tag1,id=att1)
    views = soup.findAll(tag2,class_=att2)
    description = soup.findAll(tag3,class_=att3)
    channalName = soup.findAll(tag4,class_=att4)
    video_urls = soup.findAll(tag5,id=att5)
    ##------------------------------(Store the data into list)-----------------##
    videoTitle_=[]
    list1=[]
    list2=[]
    channelName_=[]
    description_=[]
    videoURL_=[]
    channelURL_=[]
    print(len(titles))
    i = 0 # views and postedDate
    for j in range(len(titles)):
        videoTitle_.append(titles[j].text)
        list1.append(views[i].text)
        list2.append(views[i+1].text)
        channelName_.append(channalName[j].text)
        description_.append(description[j].text)
        videoURL_.append("https://www.youtube.com{}".format(video_urls[j].get('href')))
        channelURL_.append("https://www.youtube.com{}".format(channalName[j].get('href')))
        i+=2
    ##------------------------------(Store the data into CSV Files)-----------------##
    df = pd.DataFrame({'Name':videoTitle_  ,'Views':list1 ,'PostedTime':list2,'Description':description_ ,'URL':videoURL_ ,'Channel Name':channelName_ ,'Channel URL':channelURL_})
    df.to_csv(fileName+".csv", index=False)