# -*- coding: utf-8 -*-
"""
Created on Thu Oct 27 15:52:45 2022

@author: Hammad Hassan
"""

from random_word import RandomWords
def randomKeyword():
    link="https://www.youtube.com/results?search_query="
    r = RandomWords()
    list=[]
    for i in range(10):
        list.append((link+r.get_random_word()))
    return list