import matplotlib.pyplot as plt
import pandas as pd
import SortingAlgos as S

import math
def MergeSortA(array,array2,array3,array4,array5,array6,array7,start,end):
    if start!=end:
        mid=math.floor((start+end)/2)
        MergeSortA(array,array2,array3,array4,array5,array6,array7,start,mid)
        MergeSortA(array,array2,array3,array4,array5,array6,array7,mid+1,end)
        if type(array[0])==int:
            MergeA(array,array2,array3,array4,array5,array6,array7,start,mid,end)
        elif  type(array[0])==str:
            #MergeString(array,array2,array3,array4,array5,array6,array7, start, mid, end)    
           MergeString(array, start, mid, end)
           
           
           
def MergeA(A,array2,array3,array4,array5,array6,array7,p,q,r):
    L = []
    L2= []
    L3= []
    L4= []
    L5= []
    L6= []
    L7= []
    
    R = []
    R2 = []
    R3 = []
    R4 = []    
    R5 = []
    R6 = []
    R7 = []
    
    for i in range(0,q-p+1):
        L.append(A[p+i])
        L2.append(array2[p+i])
        L3.append(array3[p+i])
        L4.append(array4[p+i])
        L5.append(array5[p+i])
        L6.append(array6[p+i])
        L7.append(array7[p+i])
        
    for j in range(0,r-q):
        R.append(A[q+j+1])
        R2.append(array2[q+j+1])
        R3.append(array3[q+j+1])
        R4.append(array4[q+j+1])
        R5.append(array5[q+j+1])
        R6.append(array6[q+j+1])
        R7.append(array7[q+j+1])
        
        
    #L = A[p:q+1]
    #R = A[q+1:r+1]
    L.append(100000000000)
    R.append(100000000000)
    L2.append(100000000000)
    R2.append(100000000000)
    L3.append(100000000000)
    R3.append(100000000000)
    L4.append(100000000000)
    R4.append(100000000000)
    L5.append(100000000000)
    R5.append(100000000000)
    L6.append(100000000000)
    R6.append(100000000000)
    L7.append(100000000000)
    R7.append(100000000000)
    
    
    
    i,j = 0,0
    for k in range(p,r+1):
        if(L[i] < R[j]):
            A[k] = L[i]
            array2[k] = L2[i]
            array3[k] = L3[i] 
            array4[k] = L4[i]
            array5[k] = L5[i]
            array6[k] = L6[i]
            array7[k] = L7[i]
            
            i=i+1
        else:
            A[k] = R[j]
            array2[k] = R2[j]
            array3[k] = R3[j]
            array4[k] = R4[j]
            array5[k] = R5[j]
            array6[k] = R6[j]
            array7[k] = R7[j]
            
            j = j+1
            
def MergeStringA(A,array2,array3,array4,array5,array6,array7,p,q,r):
    L = []
    L2= []
    L3= []
    L4= []
    L5= []
    L6= []
    L7= []
    
    
    R = []
    R2 = []
    R3 = []
    R4 = []    
    R5 = []
    R6 = []
    R7 = []
    
    
    for i in range(0,q-p+1):
        L.append(A[p+i])
        L2.append(array2[p+i])
        L3.append(array3[p+i])
        L4.append(array4[p+i])
        L5.append(array5[p+i])
        L6.append(array6[p+i])
        L7.append(array7[p+i])
        
        
    for j in range(0,r-q):
        R.append(A[q+j+1])
        R2.append(array2[q+j+1])
        R3.append(array3[q+j+1])
        R4.append(array4[q+j+1])
        R5.append(array5[q+j+1])
        R6.append(array6[q+j+1])
        R7.append(array7[q+j+1])
        
        
    #L = A[p:q+1]
    #R = A[q+1:r+1]
    L.append("zzzzzzzzzzzzzzzzzzzzz")
    R.append("zzzzzzzzzzzzzzzzzzzzz")
    L2.append(100000000000)
    R2.append(100000000000)
    L3.append(100000000000)
    R3.append(100000000000)
    L4.append("zzzzzzzzzzzzzzzzzzzzz")
    R4.append("zzzzzzzzzzzzzzzzzzzzz")
    L5.append("zzzzzzzzzzzzzzzzzzzzz")
    R5.append("zzzzzzzzzzzzzzzzzzzzz")
    L6.append("zzzzzzzzzzzzzzzzzzzzz")
    R6.append("zzzzzzzzzzzzzzzzzzzzz")
    L7.append("zzzzzzzzzzzzzzzzzzzzz")
    R7.append("zzzzzzzzzzzzzzzzzzzzz")
    
    
    
    
    i,j = 0,0
    for k in range(p,r+1):
        LA = makeAscii(str(L[i]))
        RA = makeAscii(str(R[j]))
        
        if(''.join(map(chr,compareAscii(LA, RA, 0))) == L[i]):
            A[k] = L[i]
            array2[k] = L2[i]
            array3[k] = L3[i] 
            array4[k] = L4[i]
            array5[k] = L5[i]
            array6[k] = L6[i]
            array7[k] = L7[i]
            
            i=i+1
        else:
            A[k] = R[j]
            array2[k] = R2[j]
            array3[k] = R3[j]
            array4[k] = R4[j]
            array5[k] = R5[j]
            array6[k] = R6[j]
            array7[k] = R7[j]
            
            j = j+1
            
#=============================================================================
def makeAscii(A):
    arr = []
    for character in A:
        arr.append(ord(character))
    return arr

def compareAscii(A,B,n):
    if(n==0):
        A.append(-1000000)
        B.append(-1000000)
       
    if(A[n] < B[n]):
        A.pop()
        return A
    elif(A[n] > B[n]):
        B.pop()
        return B
    else:
        return compareAscii(A, B, n+1)
    
#=============================================================================

def MergeString(A,p,q,r):
    L = []
    R = []
    for i in range(0,q-p+1):
        L.append(A[p+i])
    for j in range(0,r-q):
        R.append(A[q+j+1])
    #L = A[p:q+1]
    #R = A[q+1:r+1]
    L.append("zzzzzzzzzzzzzzzzzzz")
    R.append("")
    
    
    i,j = 0,0
    for k in range(p,r+1):
        LA = makeAscii(str(L[i]))
        RA = makeAscii(str(R[j]))
        if(''.join(map(chr,compareAscii(LA, RA, 0))) == L[i]):
            A[k] = L[i]
            i=i+1
        else:
            A[k] = R[j]
            j = j+1
# =============================================================================
# def makeAscii(A):
#     arr = []
#     for character in A:
#         arr.append(ord(character))
#     return arr
# 
# def compareAscii(A,B,n):
#     if(n==0):
#         A.append(-1000)
#         B.append(-1000)
#         
#     if(A[0] < B[0]):
#         A.pop()
#         return A
#     elif(A[n] > B[n]):
#         B.pop()
#         return B
#     else:
#         return compareAscii(A, B, n+1)
# 
# 
# 
# =============================================================================








        
def data():
    
#=============================================================================
    df = pd.read_csv('YoutubeData.csv' )
    #insertion,merge-1,HybridMergeSort-1,Bubble-1,HybridMergeInsertionSort,QuickSort-1,SelectionSort-1
    #BubbleSortDescending-1,InsertionSortDescending,,QuickSortDescending-1,SelectionSortDescending-1,
#=============================================================================
    
    List1 = df['Name'].values.tolist()
    List2 = df['Views'].values.tolist()
    List3 = df['PostedTime'].values.tolist()
    List4 = df['Description'].values.tolist()
    List5 = df['URL'].values.tolist()
    List6 = df['Channel Name'].values.tolist()
    List7 = df['Channel URL'].values.tolist()
   #Name	Views			URL	Channel Name	Channel URL
    a=List1[0:1000]
    b=List2[0:1000]
    c=List3[0:1000]
    d=List4[0:1000]
    e=List5[0:1000]
    f=List6[0:1000]
    g=List7[0:1000]
    #print(a[53-1])
    MergeSortA(a, b,c,d,e,f,g,7, 70)
    
    for i in range(5,55):
        print(a[i])
    
#=============================================================================
  
#=============================================================================
#insertion Done
#Bubble Done
#Selection Done
#QuickDone


data()